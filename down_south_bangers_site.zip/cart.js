
let cart = [];

function addToCart(item, price) {
  cart.push({ item, price });
  alert(item + " added to cart!");
  updateCart();
}

function updateCart() {
  const cartItems = document.getElementById('cart-items');
  const totalPrice = document.getElementById('total-price');
  if (!cartItems || !totalPrice) return;

  cartItems.innerHTML = '';
  let total = 0;
  cart.forEach((product, index) => {
    cartItems.innerHTML += `<li>${product.item} - $${product.price}</li>`;
    total += product.price;
  });
  totalPrice.textContent = "Total: $" + total;
}
